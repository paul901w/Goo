import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { 
  Plus, 
  User, 
  ChevronRight, 
  Gift, 
  Camera, 
  Users,
  Search
} from 'lucide-react';
import { cn } from '@/lib/utils';

export default function RecipientsPage() {
  const { recipients } = useApp();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredRecipients = recipients.filter(r => 
    r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground pb-24">
      {/* Header */}
      <div className="flex items-center justify-between p-4 pt-6">
        <h2 className="text-xl font-bold">Recipients</h2>
        <button className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-secondary text-xs font-bold">
          <Gift size={16} className="text-muted-foreground" />
          <span>Invite</span>
        </button>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-3 px-4 py-2">
        <button className="flex items-center gap-2 px-4 py-2 rounded-full bg-foreground text-background text-xs font-bold">
          <Plus size={16} />
          <span>Add</span>
        </button>
        <button className="flex items-center gap-2 px-4 py-2 rounded-full bg-secondary text-xs font-bold">
          <Camera size={16} className="text-foreground" />
          <span>Upload</span>
        </button>
      </div>

      {/* Recents */}
      <div className="px-4 py-6 space-y-4">
        <h3 className="text-base font-bold">Recents</h3>
        <div className="flex gap-6 overflow-x-auto no-scrollbar pb-2">
          {recipients.slice(0, 2).map((r) => (
            <div key={r.id} className="flex flex-col items-center gap-3 shrink-0 w-20">
              <div className="relative">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center text-foreground text-xl font-bold overflow-hidden border border-primary/20">
                  {r.avatar ? (
                    <img src={r.avatar} alt={r.name} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    r.name.split(' ').map(n => n[0]).join('')
                  )}
                </div>
                <div className="wise-tag-badge">
                  <span className="wise-tag-icon">⥯</span>
                </div>
              </div>
              <div className="text-center space-y-0.5">
                <div className="text-xs font-bold truncate w-full">{r.name}</div>
                <div className="text-[10px] text-muted-foreground truncate w-full">@{r.username}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* All */}
      <div className="px-4 py-4 space-y-4">
        <h3 className="text-base font-bold">All</h3>
        <div className="bg-card rounded-2xl border border-border overflow-hidden">
          {filteredRecipients.map((r, index) => (
            <button 
              key={r.id} 
              className={cn(
                "w-full flex items-center justify-between p-4 hover:bg-secondary/50 transition-colors",
                index !== filteredRecipients.length - 1 && "border-b border-border"
              )}
            >
              <div className="flex items-center gap-4">
                <div className="relative">
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-foreground text-base font-bold overflow-hidden border border-primary/20">
                    {r.avatar ? (
                      <img src={r.avatar} alt={r.name} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      r.name.split(' ').map(n => n[0]).join('')
                    )}
                  </div>
                  <div className="wise-tag-badge">
                    <span className="wise-tag-icon">⥯</span>
                  </div>
                </div>
                <div className="text-left">
                  <div className="font-bold text-sm">{r.name}</div>
                  <div className="text-xs text-muted-foreground">@{r.username}</div>
                </div>
              </div>
              <ChevronRight size={18} className="text-muted-foreground" />
            </button>
          ))}
        </div>
      </div>

      {/* Add more phone contacts */}
      <div className="px-4 py-6 space-y-4 border-t border-border mt-4">
        <h3 className="text-base font-bold">Add more phone contacts</h3>
        <div className="w-full flex items-center justify-between py-3 group">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center text-muted-foreground">
                <Users size={20} />
              </div>
              <div className="absolute bottom-0 right-0 h-4 w-4 bg-foreground rounded-full flex items-center justify-center border-2 border-background">
                <Plus size={10} className="text-background" />
              </div>
            </div>
            <div className="text-left">
              <div className="font-bold text-sm">Abderraouf C. and 5 others are now on Wise</div>
            </div>
          </div>
          <button className="px-3 py-1.5 rounded-full bg-secondary text-xs font-bold">
            View
          </button>
        </div>
      </div>
    </div>
  );
}
