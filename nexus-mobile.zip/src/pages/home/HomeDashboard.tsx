import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { cn } from '@/lib/utils';
import { 
  Send, 
  Plus, 
  ArrowDownLeft, 
  Eye, 
  EyeOff, 
  ChevronRight,
  TrendingUp,
  X,
  ChevronDown
} from 'lucide-react';

export default function HomeDashboard() {
  const { user, accounts, isBalanceVisible, setIsBalanceVisible } = useApp();
  const [selectedCurrency, setSelectedCurrency] = useState('GBP');

  const selectedAccount = accounts.find(acc => acc.currency === selectedCurrency) || accounts[0];

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground pb-24">
      {/* Top Bar */}
      <div className="flex items-center justify-between p-4 pt-6">
        <Link to="/profile">
          <img 
            src={user.avatar} 
            alt="Profile" 
            className="h-10 w-10 rounded-full border border-border"
            referrerPolicy="no-referrer"
          />
        </Link>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setIsBalanceVisible(!isBalanceVisible)}
            className="p-2 bg-secondary rounded-full"
          >
            {isBalanceVisible ? <Eye size={20} className="text-foreground" /> : <EyeOff size={20} className="text-foreground" />}
          </button>
        </div>
      </div>

      <div className="px-4 space-y-6">
        {/* Total Balance */}
        <div className="space-y-1">
          <div className="flex items-center justify-between">
            <div className="text-xs text-muted-foreground font-medium">Total balance</div>
            <select 
              value={selectedCurrency}
              onChange={(e) => setSelectedCurrency(e.target.value)}
              className="bg-secondary text-xs font-bold rounded-full px-2 py-1"
            >
              {accounts.map(acc => (
                <option key={acc.currency} value={acc.currency}>{acc.currency}</option>
              ))}
            </select>
          </div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold tracking-tight">
              {isBalanceVisible ? `${selectedAccount.symbol}${selectedAccount.balance.toLocaleString()}` : '****'} {selectedCurrency}
            </h1>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3 overflow-x-auto no-scrollbar py-2">
          <button className="bg-foreground text-background px-5 py-2.5 rounded-full font-bold text-xs flex items-center gap-2 shrink-0">
            Send
          </button>
          <button className="bg-secondary text-foreground px-5 py-2.5 rounded-full font-bold text-xs flex items-center gap-2 shrink-0">
            Add money
          </button>
          <button className="bg-secondary text-foreground px-5 py-2.5 rounded-full font-bold text-xs flex items-center gap-2 shrink-0">
            Request <ChevronDown size={14} />
          </button>
        </div>

        {/* Main Account Card */}
        <div className="relative">
          {/* Main Card Content */}
          <div className="relative bg-card rounded-3xl p-6 space-y-6 border border-border">
            <div className="flex items-center justify-between group cursor-pointer">
              <div className="space-y-1">
                <h3 className="text-lg font-bold">Current account</h3>
                <div className="text-sm text-muted-foreground font-medium">
                  {isBalanceVisible ? `${selectedAccount.symbol}${selectedAccount.balance.toLocaleString()}` : '****'}
                </div>
              </div>
              <ChevronRight size={18} className="text-muted-foreground" />
            </div>

            <div className="bg-card rounded-2xl border border-border overflow-hidden">
              {accounts.map((account, index) => (
                <div 
                  key={account.id} 
                  className={cn(
                    "flex items-center justify-between group cursor-pointer p-4 hover:bg-secondary/50 transition-colors",
                    index !== accounts.length - 1 && "border-b border-border"
                  )}
                >
                  <div className="flex items-center gap-4">
                    <div className="h-9 w-9 rounded-full bg-secondary flex items-center justify-center overflow-hidden border border-border">
                      {account.currency === 'EUR' ? '🇪🇺' : account.currency === 'GBP' ? '🇬🇧' : account.currency}
                    </div>
                    <div className="font-bold text-sm">
                      {isBalanceVisible ? `${account.symbol}${account.balance.toLocaleString()}` : '****'}
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-muted-foreground" />
                </div>
              ))}
            </div>

            <button className="w-full bg-secondary py-2.5 rounded-full font-bold text-xs flex items-center justify-center gap-2">
              <Plus size={16} /> Account details
            </button>
          </div>
        </div>

        {/* Wallet Card */}
        <Link to="/cards" className="block group">
          <div className="bg-card border border-border rounded-[32px] p-6 relative overflow-hidden transition-all duration-500 hover:shadow-2xl hover:shadow-primary/5 active:scale-[0.98]">
            {/* Wallet Texture & Stitching */}
            <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-black/[0.02] pointer-events-none" />
            <div className="absolute inset-[4px] border border-dashed border-border/20 rounded-[28px] pointer-events-none" />
            
            <div className="flex items-center justify-between relative z-10">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="h-1.5 w-1.5 rounded-full bg-foreground shadow-[0_0_8px_rgba(156,163,175,0.5)]" />
                  <h3 className="text-sm font-bold text-foreground tracking-tight">Your Visa cards</h3>
                </div>
                <div className="flex items-center gap-2">
                  <p className="text-[9px] text-muted-foreground font-bold uppercase tracking-[0.15em] opacity-70">
                    Manage & View details
                  </p>
                  <ChevronRight size={10} className="text-muted-foreground transition-transform group-hover:translate-x-1" />
                </div>
              </div>
              
              {/* Modern Card Stack Illustration */}
              <div className="relative h-16 w-24">
                {/* Card 3 (Back) */}
                <div className="absolute top-0 right-6 h-12 w-20 bg-slate-800 rounded-lg border border-white/10 rotate-[-18deg] shadow-2xl transition-all duration-700 group-hover:rotate-[-28deg] group-hover:-translate-x-4">
                   <div className="absolute top-2 left-2 h-2 w-3 bg-yellow-500/30 rounded-sm" />
                   <div className="absolute bottom-2 right-2 h-1.5 w-4 bg-white/5 rounded-full" />
                </div>
                {/* Card 2 (Middle) */}
                <div className="absolute top-1 right-3 h-12 w-20 bg-blue-600 rounded-lg border border-white/10 rotate-[-8deg] shadow-2xl transition-all duration-700 group-hover:rotate-[-15deg] group-hover:-translate-x-2">
                   <div className="absolute top-2 left-2 h-2 w-3 bg-white/30 rounded-sm" />
                   <div className="absolute bottom-2 right-2 h-1.5 w-4 bg-white/10 rounded-full" />
                </div>
                {/* Card 1 (Front) */}
                <div className="absolute top-2 right-0 h-12 w-20 bg-slate-100 rounded-lg border border-black/5 rotate-[4deg] shadow-2xl transition-all duration-700 group-hover:rotate-[12deg] group-hover:translate-x-2">
                   <div className="absolute top-2 left-2 h-2 w-3 bg-black/10 rounded-sm" />
                   <div className="absolute bottom-2 right-2 h-1.5 w-4 bg-black/10 rounded-full" />
                   <div className="absolute top-2 right-2 text-[5px] font-black text-black/30 tracking-tighter">VISA</div>
                   <div className="absolute bottom-2 left-2 h-1 w-8 bg-black/5 rounded-full" />
                </div>
              </div>
            </div>

            {/* Wallet Clasp/Pocket Detail */}
            <div className="absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-foreground/[0.02] to-transparent pointer-events-none" />
            <div className="absolute right-0 top-1/2 -translate-y-1/2 h-14 w-1 bg-foreground/30 rounded-l-full" />
          </div>
        </Link>

        {/* Pagination Dots */}
        <div className="flex justify-center gap-2">
          <div className="h-1.5 w-1.5 rounded-full bg-foreground" />
          <div className="h-1.5 w-1.5 rounded-full bg-secondary" />
        </div>

        {/* Promo Banner */}
        <div className="bg-card border border-border rounded-3xl p-4 flex items-center gap-4 relative overflow-hidden">
          <div className="flex-1 space-y-1">
            <h4 className="font-bold text-xs">We've updated how Wise looks and works.</h4>
            <Link to="#" className="text-foreground text-xs font-bold underline underline-offset-4">Find out more</Link>
          </div>
          <div className="h-14 w-14 bg-gradient-to-br from-orange-400 to-yellow-500 rounded-2xl flex items-center justify-center shrink-0">
            <div className="text-2xl">💼</div>
          </div>
          <button className="absolute top-2 right-2 p-1 text-muted-foreground">
            <X size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}
