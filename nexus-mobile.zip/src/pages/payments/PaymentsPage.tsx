import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { 
  ChevronRight, 
  RefreshCw, 
  Mail, 
  Calendar, 
  Repeat, 
  Camera, 
  Split, 
  Link as LinkIcon,
  Plus,
  User,
  ArrowUp
} from 'lucide-react';
import { cn } from '@/lib/utils';

export default function PaymentsPage() {
  const { user } = useApp();

  const paymentTools = [
    { icon: RefreshCw, label: 'Recurring card payments', sublabel: '1 active', dashed: false },
    { icon: Mail, label: 'Forward invoices to email', sublabel: 'Save time by emailing bills and invoices to create draft payments.', dashed: false, plus: true },
    { icon: Calendar, label: 'Scheduled transfers', sublabel: 'Set up a transfer to send at a later date.', dashed: true, plus: true },
    { icon: Repeat, label: 'Direct Debits', sublabel: 'Set up and manage regular payments.', dashed: true, plus: true },
    { icon: Camera, label: 'Payment requests', sublabel: "Create and manage payments you've requested.", dashed: true, plus: true },
    { icon: Split, label: 'Bill splits', sublabel: 'Split transactions with multiple people.', dashed: true, plus: true },
  ];

  const toolsSection = [
    { 
      icon: LinkIcon, 
      label: 'Send via link', 
      sublabel: 'Create and manage links for recipients to claim money.',
      plus: true 
    },
    { 
      icon: RefreshCw, 
      label: 'Auto Conversions', 
      sublabel: 'Convert money between currencies automatically at your chosen rate.',
      plus: true 
    },
    { 
      icon: ArrowUp, 
      label: 'Auto Top-ups', 
      sublabel: 'Automatically top-up when your account is low.',
      plus: true 
    },
  ];

  const accountDetails = [
    { 
      currency: 'Euro', 
      flag: '🇪🇺', 
      detail: 'IBAN ending .. 98456',
      code: 'EUR'
    },
    { 
      currency: 'British Pound', 
      flag: '🇬🇧', 
      detail: 'Account number ending .. 80185',
      code: 'GBP'
    },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground pb-24">
      {/* Header */}
      <div className="p-4 pt-6 space-y-4">
        <h2 className="text-2xl font-bold">Payments</h2>
        <div className="flex gap-3">
          <button className="px-5 py-2 rounded-full bg-foreground text-background font-bold text-xs">
            Send
          </button>
          <button className="px-5 py-2 rounded-full bg-secondary text-foreground font-bold text-xs">
            Request
          </button>
        </div>
      </div>

      {/* Payment Tools List */}
      <div className="px-4">
        <div className="bg-card rounded-2xl border border-border overflow-hidden">
          {paymentTools.map((tool, index) => (
            <button 
              key={index}
              className={cn(
                "w-full flex items-start justify-between p-4 hover:bg-secondary/50 transition-colors",
                index !== paymentTools.length - 1 && "border-b border-border"
              )}
            >
              <div className="flex items-start gap-4">
                <div className="relative shrink-0">
                  <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center text-foreground border border-border">
                    <tool.icon size={20} />
                  </div>
                  {tool.plus && (
                    <div className="absolute bottom-0 right-0 h-4 w-4 bg-foreground rounded-full flex items-center justify-center border-2 border-card">
                      <Plus size={10} className="text-background" />
                    </div>
                  )}
                </div>
                <div className="text-left space-y-0.5">
                  <div className="font-bold text-base leading-tight">{tool.label}</div>
                  <div className="text-xs text-muted-foreground leading-snug pr-4">
                    {tool.sublabel}
                  </div>
                </div>
              </div>
              <ChevronRight size={18} className="text-muted-foreground mt-1" />
            </button>
          ))}
        </div>
      </div>

      {/* Payment Tools Section */}
      <div className="px-4 py-8 space-y-4">
        <h3 className="text-xl font-bold">Payment tools</h3>
        
        <div className="bg-card rounded-2xl border border-border overflow-hidden">
          {/* Wisetag */}
          <button className="w-full flex items-center justify-between p-5 hover:bg-secondary/50 transition-colors border-b border-border">
            <div className="flex items-center gap-4">
              <div className="relative shrink-0">
                <img 
                  src={user.avatar} 
                  alt={user.name} 
                  className="h-12 w-12 rounded-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute -bottom-1 -right-1 h-5 w-5 bg-foreground rounded-full flex items-center justify-center border-2 border-card">
                  <span className="text-[10px] font-bold text-background">⥯</span>
                </div>
              </div>
              <div className="text-left">
                <div className="font-bold text-lg leading-tight">Your Wisetag</div>
                <div className="text-sm text-muted-foreground">@{user.email.split('@')[0]}</div>
              </div>
            </div>
            <ChevronRight size={20} className="text-muted-foreground" />
          </button>

          {/* Other Tools */}
          {toolsSection.map((tool, index) => (
            <button 
              key={index}
              className={cn(
                "w-full flex items-start justify-between p-5 hover:bg-secondary/50 transition-colors",
                index !== toolsSection.length - 1 && "border-b border-border"
              )}
            >
              <div className="flex items-start gap-4">
                <div className="relative shrink-0">
                  <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center text-foreground border border-border">
                    <tool.icon size={20} />
                  </div>
                  {tool.plus && (
                    <div className="absolute bottom-0 right-0 h-4 w-4 bg-foreground rounded-full flex items-center justify-center border-2 border-card">
                      <Plus size={10} className="text-background" />
                    </div>
                  )}
                </div>
                <div className="text-left space-y-0.5">
                  <div className="font-bold text-lg leading-tight">{tool.label}</div>
                  <div className="text-sm text-muted-foreground leading-snug pr-4">
                    {tool.sublabel}
                  </div>
                </div>
              </div>
              <ChevronRight size={20} className="text-muted-foreground mt-1" />
            </button>
          ))}
        </div>
      </div>

      {/* Account Details Section */}
      <div className="px-4 pb-8 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-bold">Account details</h3>
          <button className="text-foreground font-bold text-sm underline underline-offset-4 opacity-80">See all</button>
        </div>
        
        <div className="bg-card rounded-2xl border border-border overflow-hidden">
          {accountDetails.map((account, index) => (
            <Link 
              key={index}
              to={`/payments/account-details/${account.code}`}
              className={cn(
                "w-full flex items-center justify-between p-5 hover:bg-secondary/50 transition-colors",
                index !== accountDetails.length - 1 && "border-b border-border"
              )}
            >
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center text-2xl border border-border">
                  {account.flag}
                </div>
                <div className="text-left">
                  <div className="font-bold text-lg leading-tight">{account.currency}</div>
                  <div className="text-sm text-muted-foreground">{account.detail}</div>
                </div>
              </div>
              <ChevronRight size={20} className="text-muted-foreground" />
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
