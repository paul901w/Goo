import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Copy, 
  Share2, 
  ChevronRight,
  CheckCircle2
} from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';

interface AccountDetailItemProps {
  label: string;
  value: string;
  subtext?: string;
}

function AccountDetailItem({ label, value, subtext }: AccountDetailItemProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex items-start justify-between py-4 group">
      <div className="space-y-1 pr-8">
        <div className="text-sm text-muted-foreground">{label}</div>
        <div className="text-lg font-bold break-all">{value}</div>
        {subtext && <div className="text-xs text-muted-foreground">{subtext}</div>}
      </div>
      <button 
        onClick={handleCopy}
        className="shrink-0 h-10 w-10 rounded-full bg-secondary flex items-center justify-center text-foreground hover:bg-secondary/80 transition-colors"
      >
        {copied ? <CheckCircle2 size={20} /> : <Copy size={20} />}
      </button>
    </div>
  );
}

export default function AccountDetailsPage() {
  const { code } = useParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('Fees');

  const isGbp = code === 'GBP';

  const details = isGbp ? {
    currency: 'GBP',
    flag: '🇬🇧',
    name: 'Khaled Rahene',
    accountNumber: '48380185',
    sortCode: '23-08-01',
    iban: 'GB05 TRWI 2308 0148 3801 85',
    swift: 'TRWIGB2LXXX',
    address: 'Wise Payments Limited, 1st Floor, Worship Square, 65 Clifton Street, London, EC2A 4JE, United Kingdom'
  } : {
    currency: 'Euro',
    flag: '🇪🇺',
    name: 'Khaled Rahene',
    accountNumber: 'BE89 3770 1234 5678',
    sortCode: 'N/A',
    iban: 'BE89 3770 1234 5678',
    swift: 'TRWIBEB1XXX',
    address: 'Wise Europe SA, Avenue Louise 54, Room s52, 1050 Brussels, Belgium'
  };

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground pb-12">
      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <button 
          onClick={() => navigate(-1)}
          className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <ArrowLeft size={20} />
        </button>
        <div className="flex flex-col items-center">
          <div className="font-bold text-lg">{details.currency}</div>
          <div className="text-xs text-muted-foreground">Account details</div>
        </div>
        <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center text-xl">
          {details.flag}
        </div>
      </div>

      <div className="px-4 pt-4 space-y-6">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h2 className="text-2xl font-bold">Receive {details.currency}</h2>
            <p className="text-sm text-muted-foreground">
              From {isGbp ? 'the UK' : 'Europe'} and <span className="text-foreground underline opacity-80">150+ countries</span>
            </p>
          </div>
          <button className="px-6 py-2 rounded-full bg-secondary text-foreground font-bold text-sm flex items-center gap-2">
            Share
          </button>
        </div>

        {/* Details Card */}
        <div className="bg-card rounded-[32px] p-6 border border-border space-y-2">
          <AccountDetailItem label="Name" value={details.name} />
          <div className="h-px bg-border/50" />
          <AccountDetailItem label="Account number" value={details.accountNumber} />
          <div className="h-px bg-border/50" />
          {isGbp && (
            <>
              <AccountDetailItem 
                label="Sort code" 
                value={details.sortCode} 
                subtext="Only used for domestic transfers"
              />
              <div className="h-px bg-border/50" />
            </>
          )}
          <AccountDetailItem 
            label="IBAN" 
            value={details.iban} 
            subtext={`Can receive ${details.currency} and other currencies`}
          />
          <div className="h-px bg-border/50" />
          <AccountDetailItem 
            label="Swift/BIC" 
            value={details.swift} 
            subtext="Only used for international Swift transfers"
          />
          <div className="h-px bg-border/50" />
          <AccountDetailItem 
            label="Bank name and address" 
            value={details.address} 
          />
          <div className="pt-2">
            <p className="text-xs text-muted-foreground">
              Some senders may need this. <span className="text-foreground underline opacity-80">Learn more</span>
            </p>
          </div>
        </div>

        {/* Quick Facts */}
        <div className="space-y-4">
          <h3 className="text-xl font-bold">Quick facts</h3>
          <div className="flex gap-2">
            {['Fees', 'Speed', 'Limits'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={cn(
                  "px-6 py-2 rounded-full font-bold text-sm transition-colors",
                  activeTab === tab ? "bg-foreground text-background" : "bg-secondary text-muted-foreground"
                )}
              >
                {tab}
              </button>
            ))}
          </div>

          <div className="space-y-4">
            <div className="text-sm font-medium">What does it cost?</div>
            <div className="bg-card rounded-[32px] p-6 border border-border">
              <button className="w-full flex items-center justify-between group">
                <div className="text-left space-y-4">
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">From {isGbp ? 'the UK' : 'Europe'} (domestic)</div>
                    <div className="text-lg font-bold">No fees</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">From outside {isGbp ? 'the UK' : 'Europe'} (Swift)</div>
                    <div className="text-lg font-bold">2.16 {details.currency} Wise fee</div>
                    <div className="text-xs text-muted-foreground">Bank fees may also apply</div>
                  </div>
                </div>
                <ChevronRight size={24} className="text-muted-foreground group-hover:text-foreground transition-colors" />
              </button>
            </div>
          </div>
        </div>

        {/* Availability */}
        <div className="space-y-4">
          <h3 className="text-xl font-bold">Availability</h3>
          <div className="bg-card rounded-[32px] p-6 border border-border flex items-start gap-4">
            <div className="h-6 w-6 rounded-full bg-foreground/10 flex items-center justify-center shrink-0 mt-1">
              <CheckCircle2 size={16} className="text-foreground" />
            </div>
            <div className="space-y-1">
              <div className="font-bold">Direct Debits available</div>
              <p className="text-sm text-muted-foreground">
                Make regular payments. Works with Amazon, PayPal, Stripe and more.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-4 pb-8 text-center">
          <button className="text-sm text-muted-foreground font-medium">
            How can we improve? Details not accepted? <span className="text-foreground underline opacity-80">Give feedback</span>
          </button>
        </div>
      </div>
    </div>
  );
}
