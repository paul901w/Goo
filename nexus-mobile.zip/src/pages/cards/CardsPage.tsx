import { useNavigate } from 'react-router-dom';
import { Card } from '@/components/Card';
import { useApp } from '@/context/AppContext';
import { 
  Plus, 
  Shield, 
  CreditCard, 
  Lock, 
  Unlock, 
  Eye, 
  Snowflake, 
  Grid, 
  ChevronRight, 
  List, 
  Settings, 
  Gauge, 
  PenTool, 
  RefreshCw, 
  Trash2,
  TrainFront,
  X,
  Fingerprint
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState, useCallback } from 'react';
import { BiometricAuthModal } from '@/components/BiometricAuthModal';

export default function CardsPage() {
  const { cards, toggleCardStatus } = useApp();
  const [activeCardIndex, setActiveCardIndex] = useState(0);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isShowPinOpen, setIsShowPinOpen] = useState(false);
  
  // Biometric Auth State
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState<{ type: string; data?: any } | null>(null);

  const navigate = useNavigate();

  const manageItems = [
    { icon: List, label: 'View recent card transactions', path: '/cards/transactions' },
    { icon: Settings, label: 'Card controls', path: '/cards/controls' },
    { icon: Gauge, label: 'Your spending limits', path: '/cards/spending-limits' },
    { icon: Lock, label: 'Unblock PIN', path: '/cards/unblock-pin' },
    { icon: PenTool, label: 'Edit card', path: '/cards/edit' },
    { icon: RefreshCw, label: 'Replace card', path: '/cards/replace' },
    { icon: Trash2, label: 'Delete card', path: '/cards/delete' },
  ];

  const activeCard = cards[activeCardIndex] || cards[0];

  const handleSecureAction = (type: string, data?: any) => {
    const card = cards[activeCardIndex] || cards[0];
    if (!card) return;
    setPendingAction({ type, data: { cardId: card.id, ...data } });
    setIsAuthModalOpen(true);
  };

  const onAuthSuccess = useCallback(() => {
    setIsAuthModalOpen(false);
    if (!pendingAction) return;

    const { type, data } = pendingAction;
    setPendingAction(null);

    switch (type) {
      case 'SHOW_PIN':
        setIsShowPinOpen(true);
        break;
      case 'CARD_DETAILS':
        setIsDetailsOpen(true);
        break;
      case 'TOGGLE_FREEZE':
        if (data?.cardId) {
          toggleCardStatus(data.cardId);
        }
        break;
      case 'NAVIGATE':
        if (data?.path && data?.cardId) {
          navigate(data.path, { state: { cardId: data.cardId } });
        }
        break;
      default:
        break;
    }
  }, [pendingAction, toggleCardStatus, navigate]);

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground pb-24">
      <BiometricAuthModal 
        isOpen={isAuthModalOpen}
        onClose={() => {
          setIsAuthModalOpen(false);
          setPendingAction(null);
        }}
        onSuccess={onAuthSuccess}
        title="Confirm Identity"
        description={
          pendingAction?.type === 'SHOW_PIN' ? "Scan fingerprint to see your PIN" :
          pendingAction?.type === 'CARD_DETAILS' ? "Scan fingerprint to reveal card details" :
          pendingAction?.type === 'TOGGLE_FREEZE' ? `Scan fingerprint to ${activeCard?.status === 'Active' ? 'freeze' : 'unfreeze'} card` :
          "Scan fingerprint to access this function"
        }
      />
      {/* Header */}
      <div className="flex items-center justify-between p-4 pt-6">
        <button className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-secondary text-xs font-medium">
          <TrainFront size={16} className="text-foreground" />
          <span>Travel hub</span>
        </button>
        <button 
          onClick={() => handleSecureAction('NAVIGATE', { path: '/cards/replace' })}
          className="px-4 py-2 rounded-full bg-foreground text-background text-xs font-bold"
        >
          Order a card
        </button>
      </div>

      {/* Card Carousel */}
      <div className="relative overflow-hidden py-4">
        <div className="flex gap-4 px-4 overflow-x-auto no-scrollbar snap-x snap-mandatory" onScroll={(e) => {
          const scrollLeft = e.currentTarget.scrollLeft;
          const cardWidth = e.currentTarget.offsetWidth * 0.85 + 16; // 85% width + 16px gap
          setActiveCardIndex(Math.round(scrollLeft / cardWidth));
        }}>
          {cards.map((card, index) => (
            <div key={card.id} className="min-w-[85%] snap-center">
              <Card 
                onClick={() => handleSecureAction('TOGGLE_FREEZE', { cardId: card.id })}
                className={cn(
                  "relative h-44 w-full p-6 text-white flex flex-col justify-between overflow-hidden rounded-3xl border-none cursor-pointer active:scale-95 transition-transform",
                  index === 0 ? "bg-gradient-to-br from-teal-400 via-emerald-400 to-yellow-200" : "bg-slate-800",
                  card.status === 'Frozen' && "opacity-60 grayscale"
                )}
              >
                <div className="flex justify-end">
                  <div className="flex items-center gap-1 text-xl font-bold italic">
                    <span className="text-2xl">⥯</span>WISE
                  </div>
                </div>
                
                <div className="flex justify-between items-end">
                  <div className="text-base font-bold">{card.brand.toUpperCase()}</div>
                </div>

                {card.status === 'Frozen' && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-[1px]">
                    <Snowflake size={40} className="text-white" />
                  </div>
                )}
              </Card>
              
              <div className="mt-4 text-center">
                <div className="text-base font-bold">{card.type} card  •••• {card.last4}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-around items-start px-4 py-6">
        <button 
          onClick={() => handleSecureAction('SHOW_PIN')}
          className="flex flex-col items-center gap-2 group"
        >
          <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center group-active:scale-95 transition-transform">
            <Grid size={20} className="text-foreground" />
          </div>
          <span className="text-[10px] font-bold text-foreground">Show PIN</span>
        </button>
        <button className="flex flex-col items-center gap-2 group" onClick={() => handleSecureAction('CARD_DETAILS')}>
          <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center group-active:scale-95 transition-transform">
            <CreditCard size={20} className="text-foreground" />
          </div>
          <span className="text-[10px] font-bold text-foreground">Card details</span>
        </button>
        <button 
          onClick={() => handleSecureAction('TOGGLE_FREEZE')}
          className="flex flex-col items-center gap-2 group"
        >
          <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center group-active:scale-95 transition-transform">
            <Snowflake size={20} className="text-foreground" />
          </div>
          <span className="text-[10px] font-bold text-foreground">
            {activeCard?.status === 'Active' ? 'Freeze card' : 'Unfreeze card'}
          </span>
        </button>
      </div>

      {isDetailsOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4" onClick={() => setIsDetailsOpen(false)}>
          <div className="bg-card/90 backdrop-blur-xl w-full max-w-[340px] rounded-[32px] p-5 space-y-5 animate-in zoom-in-95 border border-white/10 shadow-2xl relative" onClick={(e) => e.stopPropagation()}>
            <button 
              onClick={() => setIsDetailsOpen(false)}
              className="absolute top-4 right-4 h-8 w-8 rounded-full bg-secondary/50 flex items-center justify-center border border-border/40 active:scale-95 transition-transform"
            >
              <X size={18} />
            </button>

            <div className="flex justify-center">
              <div className="h-1 w-10 bg-muted/40 rounded-full" />
            </div>
            
            <div className="text-center font-bold text-[11px] text-muted-foreground uppercase tracking-[0.2em]">
              {activeCard?.type} card •••• {activeCard?.last4}
            </div>

            <div className="bg-card/50 rounded-2xl border border-border/30 overflow-hidden">
              {[
                { label: 'Cardholder name', value: 'KHALED RAHENE' },
                { label: 'Card number', value: `4242 4242 4242 ${activeCard?.last4}` },
                { label: 'Expiry date', value: '12/28' },
                { label: 'Security code', value: '123' },
                { label: 'Billing address', value: '430378 York House, Lancashire, PR3 1NJ, United Kingdom.' },
              ].map((item, i) => (
                <div 
                  key={i} 
                  className={cn(
                    "flex justify-between items-start gap-3 p-3.5",
                    i !== 4 && "border-b border-border/30"
                  )}
                >
                  <div className="flex-1 min-w-0">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-0.5">{item.label}</div>
                    <div className="font-bold text-[14px] leading-tight break-words">{item.value}</div>
                  </div>
                  <button 
                    className="text-[10px] font-bold text-foreground bg-secondary/50 px-3 py-1.5 rounded-full shrink-0 border border-border/40 active:scale-90 transition-transform"
                    onClick={() => navigator.clipboard.writeText(item.value)}
                  >
                    Copy
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {isShowPinOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4" onClick={() => setIsShowPinOpen(false)}>
          <div className="bg-card/80 backdrop-blur-md w-full max-w-md rounded-3xl p-6 space-y-6 animate-in zoom-in-95 border border-white/20 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-center">
              <div className="h-1 w-12 bg-muted rounded-full" />
            </div>
            
            <div className="text-center font-bold text-sm text-muted-foreground uppercase tracking-widest">
              {activeCard?.type} card •••• {activeCard?.last4}
            </div>

            <div className="flex flex-col items-center justify-center py-8 space-y-6">
              <div className="text-center space-y-2">
                <div className="text-sm text-muted-foreground font-medium uppercase tracking-widest">Your PIN is</div>
                <div className="flex gap-4">
                  {[7, 4, 1, 9].map((num, i) => (
                    <div key={i} className="h-16 w-12 bg-secondary rounded-2xl flex items-center justify-center text-3xl font-bold border border-border">
                      {num}
                    </div>
                  ))}
                </div>
              </div>
              <p className="text-xs text-muted-foreground text-center max-w-[200px]">
                This PIN will be hidden automatically in 10 seconds.
              </p>
              <button 
                onClick={() => setIsShowPinOpen(false)}
                className="bg-foreground text-background px-8 py-2.5 rounded-full font-bold text-sm"
              >
                Got it
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Google Pay Button */}
      <div className="px-4 py-2">
        <button className="w-full py-2.5 rounded-full border border-border flex items-center justify-center gap-2 font-bold text-xs">
          Add to <span className="flex items-center"><span className="text-blue-500">G</span> <span className="ml-1">Pay</span></span>
        </button>
      </div>

      {/* Promo Banner */}
      <div className="px-4 py-6">
        <div className="relative bg-secondary/50 rounded-3xl p-5 flex items-center gap-4 overflow-hidden">
          <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center shrink-0">
            <div className="text-3xl">🎒</div>
          </div>
          <div className="flex-1 space-y-2">
            <div className="text-xs font-medium leading-tight pr-8">
              Get a Young Explorer card for 6–17 year olds
            </div>
            <button 
              onClick={() => handleSecureAction('NAVIGATE', { path: '/cards/replace' })}
              className="text-foreground text-xs font-bold underline underline-offset-4"
            >
              Order card
            </button>
          </div>
          <button className="absolute top-4 right-4 text-muted-foreground">
            <X size={16} />
          </button>
        </div>
      </div>

      {/* Manage Card List */}
      <div className="px-4 space-y-4">
        <h3 className="text-base font-bold px-1 border-t border-border pt-4">Manage card</h3>
        <div className="bg-card rounded-2xl border border-border overflow-hidden">
          {manageItems.map((item, index) => (
            <button 
              key={index}
              onClick={() => handleSecureAction('NAVIGATE', { path: item.path })}
              className={cn(
                "w-full flex items-center justify-between p-4 hover:bg-secondary/50 transition-colors",
                index !== manageItems.length - 1 && "border-b border-border"
              )}
            >
              <div className="flex items-center gap-4">
                <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center group-active:scale-95 transition-transform">
                  <item.icon size={18} className="text-foreground" />
                </div>
                <span className="font-bold text-sm text-foreground">{item.label}</span>
              </div>
              <ChevronRight size={18} className="text-muted-foreground" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
