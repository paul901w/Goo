import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, PenTool, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '@/context/AppContext';

const EditCardPage: React.FC = () => {
  const navigate = useNavigate();
  const { cards } = useApp();
  const [isSuccess, setIsSuccess] = useState(false);
  const [cardName, setCardName] = useState('Main Card');

  const handleSave = () => {
    // Simulate API call
    setTimeout(() => {
      setIsSuccess(true);
    }, 1000);
  };

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between p-4 pt-6">
        <button 
          onClick={() => navigate(-1)}
          className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <X size={24} />
        </button>
        <h1 className="text-xl font-bold">Edit card</h1>
        <div className="w-10" />
      </header>

      <main className="flex-1 p-6 flex flex-col items-center justify-center space-y-8">
        <AnimatePresence mode="wait">
          {!isSuccess ? (
            <motion.div 
              key="initial"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm space-y-8"
            >
              <div className="h-24 w-24 rounded-full bg-secondary flex items-center justify-center mx-auto">
                <PenTool size={48} className="text-foreground" />
              </div>
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Card nickname</label>
                  <input 
                    type="text" 
                    value={cardName}
                    onChange={(e) => setCardName(e.target.value)}
                    className="w-full bg-secondary border-none rounded-2xl p-4 text-lg font-bold focus:ring-2 focus:ring-foreground outline-none"
                    placeholder="e.g. Daily spending"
                  />
                </div>
                <p className="text-sm text-muted-foreground text-center">
                  Give your card a name to help you keep track of your spending.
                </p>
              </div>
              <button 
                onClick={handleSave}
                className="w-full bg-foreground text-background py-4 rounded-full font-bold text-lg shadow-lg active:scale-95 transition-transform"
              >
                Save changes
              </button>
            </motion.div>
          ) : (
            <motion.div 
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="w-full max-w-sm space-y-8 text-center"
            >
              <div className="h-24 w-24 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto text-emerald-500">
                <CheckCircle2 size={48} />
              </div>
              <div className="space-y-2">
                <h2 className="text-2xl font-bold">Card updated!</h2>
                <p className="text-muted-foreground">
                  Your card nickname has been updated successfully.
                </p>
              </div>
              <button 
                onClick={() => navigate('/cards')}
                className="w-full bg-foreground text-background py-4 rounded-full font-bold text-lg shadow-lg active:scale-95 transition-transform"
              >
                Back to cards
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
};

export default EditCardPage;
