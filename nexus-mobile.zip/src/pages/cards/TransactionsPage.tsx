import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { X, Search, BarChart3 } from 'lucide-react';
import { useApp } from '@/context/AppContext';

const TransactionsPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { cards } = useApp();
  
  const cardId = location.state?.cardId;
  const selectedCard = cards.find(c => c.id === cardId) || cards[0];

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between p-4 pt-6">
        <button 
          onClick={() => navigate(-1)}
          className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <X size={24} />
        </button>
        <h1 className="text-xl font-bold">Transactions</h1>
        <div className="flex gap-2">
          <button className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center">
            <Search size={20} />
          </button>
          <button className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center">
            <BarChart3 size={20} />
          </button>
        </div>
      </header>
      <main className="flex-1 p-4 space-y-6">
        <div className="flex gap-2">
          <button className="px-4 py-1.5 rounded-full bg-foreground text-background text-sm font-bold flex items-center gap-1">
            {selectedCard.type} card {selectedCard.last4} <X size={14} />
          </button>
          <button className="px-4 py-1.5 rounded-full bg-secondary text-sm font-bold">
            Include hidden
          </button>
          <button className="px-4 py-1.5 rounded-full bg-secondary text-sm font-bold">
            Type
          </button>
        </div>

        <div className="flex flex-col items-center justify-center pt-20 space-y-6">
          <div className="relative">
            <div className="h-32 w-32 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center">
              <div className="text-4xl">🌍</div>
            </div>
            {/* Simple representation of coins */}
            <div className="absolute -top-2 -right-2 h-10 w-10 rounded-full bg-yellow-500 border-2 border-background" />
            <div className="absolute top-10 -left-4 h-8 w-8 rounded-full bg-yellow-500 border-2 border-background" />
          </div>
          <p className="text-lg font-medium text-muted-foreground">Your filters have returned no results</p>
          <button className="w-full py-3 rounded-full bg-foreground text-background font-bold text-base">
            Clear filters
          </button>
        </div>
      </main>
    </div>
  );
};

export default TransactionsPage;
