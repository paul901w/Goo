import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { X, Globe, Smartphone, Landmark, Lock, Plane } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useApp } from '@/context/AppContext';

const CardControlsPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { cards } = useApp();
  
  const cardId = location.state?.cardId;
  const selectedCard = cards.find(c => c.id === cardId) || cards[0];

  const [controls, setControls] = useState([
    { id: 'online', icon: Globe, title: 'Online payments', description: 'Pay for goods and services on the internet.', enabled: true },
    { id: 'mobile', icon: Smartphone, title: 'Mobile wallet', description: 'Use your mobile device to pay or withdraw cash.', enabled: true },
    { id: 'atm', icon: Landmark, title: 'Cash withdrawals', description: 'Tap your mobile device to withdraw at ATMs.', enabled: true },
    { id: 'non3d', icon: Lock, title: 'Non-3D secure payments', description: 'Allow online payments that don\'t require 3D Secure authentication.', enabled: true },
    { id: 'overseas', icon: Plane, title: 'Overseas payments', description: 'Allow in-store mobile wallet payments outside of United Kingdom.', enabled: true },
  ]);

  const toggleControl = (id: string) => {
    setControls(prev => prev.map(c => c.id === id ? { ...c, enabled: !c.enabled } : c));
  };

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between p-4 pt-6">
        <button 
          onClick={() => navigate(-1)}
          className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center active:scale-95 transition-transform"
        >
          <X size={24} />
        </button>
        <div className="text-center">
          <h1 className="text-xl font-bold leading-tight">Card controls</h1>
          <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">
            {selectedCard.type} •••• {selectedCard.last4}
          </p>
        </div>
        <div className="w-10" />
      </header>
      
      <main className="flex-1 p-4 space-y-6">
        <p className="text-sm text-muted-foreground px-1">
          Customise how you can use your {selectedCard.type} card.
        </p>

        <div className="bg-card rounded-2xl border border-border overflow-hidden">
          {controls.map((control, index) => (
            <div 
              key={control.id} 
              className={cn(
                "flex items-center justify-between p-4 transition-colors",
                index !== controls.length - 1 && "border-b border-border"
              )}
            >
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center shrink-0">
                  <control.icon size={22} className="text-foreground" />
                </div>
                <div className="text-left space-y-0.5">
                  <h3 className="font-bold text-[15px] leading-tight text-foreground">
                    {control.title}
                  </h3>
                  <p className="text-[13px] leading-snug text-muted-foreground max-w-[200px]">
                    {control.description}
                  </p>
                </div>
              </div>
              
              <button 
                onClick={() => toggleControl(control.id)}
                className={cn(
                  "h-7 w-12 rounded-full relative transition-colors duration-200 ease-in-out shrink-0",
                  control.enabled ? "bg-foreground" : "bg-muted"
                )}
              >
                <div className={cn(
                  "absolute top-1 h-5 w-5 rounded-full transition-all duration-200 shadow-sm",
                  control.enabled ? "translate-x-6 bg-background" : "translate-x-1 bg-white"
                )} />
              </button>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default CardControlsPage;
