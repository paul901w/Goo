import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { X, Trash2, CheckCircle2, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '@/context/AppContext';

const DeleteCardPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { cards } = useApp();
  const [isSuccess, setIsSuccess] = useState(false);

  const cardId = location.state?.cardId;
  const selectedCard = cards.find(c => c.id === cardId) || cards[0];

  const handleDelete = () => {
    // Simulate API call
    setTimeout(() => {
      setIsSuccess(true);
    }, 1200);
  };

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between p-4 pt-6">
        <button 
          onClick={() => navigate(-1)}
          className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <X size={24} />
        </button>
        <div className="text-center">
          <h1 className="text-xl font-bold leading-tight">Delete card</h1>
          <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">
            {selectedCard.type} •••• {selectedCard.last4}
          </p>
        </div>
        <div className="w-10" />
      </header>

      <main className="flex-1 p-6 flex flex-col items-center justify-center space-y-8">
        <AnimatePresence mode="wait">
          {!isSuccess ? (
            <motion.div 
              key="initial"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm space-y-8 text-center"
            >
              <div className="h-24 w-24 rounded-full bg-destructive/10 flex items-center justify-center mx-auto text-destructive">
                <Trash2 size={48} />
              </div>
              <div className="space-y-4">
                <h2 className="text-2xl font-bold">Are you sure?</h2>
                <div className="bg-destructive/5 border border-destructive/20 p-4 rounded-2xl flex items-start gap-3 text-left">
                  <AlertTriangle size={20} className="text-destructive shrink-0 mt-0.5" />
                  <p className="text-sm text-destructive-foreground">
                    Deleting your card is permanent and cannot be undone. You'll lose access to this card immediately.
                  </p>
                </div>
              </div>
              <button 
                onClick={handleDelete}
                className="w-full bg-destructive text-destructive-foreground py-4 rounded-full font-bold text-lg shadow-lg active:scale-95 transition-transform"
              >
                Delete permanently
              </button>
              <button 
                onClick={() => navigate(-1)}
                className="w-full bg-secondary text-foreground py-4 rounded-full font-bold text-lg active:scale-95 transition-transform"
              >
                Cancel
              </button>
            </motion.div>
          ) : (
            <motion.div 
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="w-full max-w-sm space-y-8 text-center"
            >
              <div className="h-24 w-24 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto text-emerald-500">
                <CheckCircle2 size={48} />
              </div>
              <div className="space-y-2">
                <h2 className="text-2xl font-bold">Card deleted!</h2>
                <p className="text-muted-foreground">
                  Your card has been successfully removed from your account.
                </p>
              </div>
              <button 
                onClick={() => navigate('/cards')}
                className="w-full bg-foreground text-background py-4 rounded-full font-bold text-lg shadow-lg active:scale-95 transition-transform"
              >
                Back to cards
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
};

export default DeleteCardPage;
