import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { X, Lock, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '@/context/AppContext';

const UnblockPinPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { cards } = useApp();
  const [isSuccess, setIsSuccess] = useState(false);

  const cardId = location.state?.cardId;
  const selectedCard = cards.find(c => c.id === cardId) || cards[0];

  const handleUnblock = () => {
    // Simulate API call
    setTimeout(() => {
      setIsSuccess(true);
    }, 1000);
  };

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between p-4 pt-6">
        <button 
          onClick={() => navigate(-1)}
          className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <X size={24} />
        </button>
        <div className="text-center">
          <h1 className="text-xl font-bold leading-tight">Unblock PIN</h1>
          <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">
            {selectedCard.type} •••• {selectedCard.last4}
          </p>
        </div>
        <div className="w-10" />
      </header>

      <main className="flex-1 p-6 flex flex-col items-center justify-center space-y-8">
        <AnimatePresence mode="wait">
          {!isSuccess ? (
            <motion.div 
              key="initial"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm space-y-8 text-center"
            >
              <div className="h-24 w-24 rounded-full bg-secondary flex items-center justify-center mx-auto">
                <Lock size={48} className="text-foreground" />
              </div>
              <div className="space-y-2">
                <h2 className="text-2xl font-bold">Forgot your PIN?</h2>
                <p className="text-muted-foreground">
                  If you've entered your PIN incorrectly too many times, you can unblock it here.
                </p>
              </div>
              <button 
                onClick={handleUnblock}
                className="w-full bg-foreground text-background py-4 rounded-full font-bold text-lg shadow-lg active:scale-95 transition-transform"
              >
                Unblock now
              </button>
            </motion.div>
          ) : (
            <motion.div 
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="w-full max-w-sm space-y-8 text-center"
            >
              <div className="h-24 w-24 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto text-emerald-500">
                <CheckCircle2 size={48} />
              </div>
              <div className="space-y-2">
                <h2 className="text-2xl font-bold">PIN unblocked!</h2>
                <p className="text-muted-foreground">
                  You can now use your card as normal. Remember to use your correct PIN next time.
                </p>
              </div>
              <button 
                onClick={() => navigate('/cards')}
                className="w-full bg-foreground text-background py-4 rounded-full font-bold text-lg shadow-lg active:scale-95 transition-transform"
              >
                Back to cards
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
};

export default UnblockPinPage;
