import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { X, Gauge, ChevronRight, CheckCircle2 } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { cn } from '@/lib/utils';

const CardSpendingLimitsPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { cards } = useApp();
  const [selectedCard, setSelectedCard] = useState<any>(null);
  const [limitValue, setLimitValue] = useState('1000');
  const [isSuccess, setIsSuccess] = useState(false);

  useEffect(() => {
    const cardId = location.state?.cardId;
    if (cardId) {
      const card = cards.find(c => c.id === cardId);
      if (card) {
        setSelectedCard(card);
      }
    }
  }, [location.state, cards]);

  const handleSetLimit = () => {
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      setSelectedCard(null);
    }, 2000);
  };

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between p-4 pt-6">
        <button 
          onClick={() => navigate(-1)}
          className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <X size={24} />
        </button>
        <h1 className="text-xl font-bold">Your spending limits</h1>
        <div className="w-10" />
      </header>
      <main className="flex-1 p-4 space-y-8">
        <button className="flex items-center justify-between p-4 bg-secondary rounded-2xl w-full">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-background flex items-center justify-center shrink-0">
              <Gauge size={24} className="text-foreground" />
            </div>
            <div className="text-left">
              <h3 className="font-bold text-lg leading-tight">Account limits</h3>
              <p className="text-sm text-muted-foreground">The amount that can be spent and withdrawn across all your cards</p>
            </div>
          </div>
          <ChevronRight size={20} className="text-muted-foreground" />
        </button>

        <div className="space-y-4">
          <h2 className="text-base font-bold px-1">Limits per card</h2>
          <div className="space-y-2">
            {cards.map((card) => (
              <div key={card.id} className="flex items-center justify-between p-4 border border-border rounded-2xl">
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center shrink-0">
                    <div className="text-2xl">💳</div>
                  </div>
                  <div className="text-left">
                    <h3 className="font-bold text-base leading-tight">{card.type} card •••• {card.last4}</h3>
                    <p className="text-sm text-muted-foreground">Ready to use</p>
                  </div>
                </div>
                <button 
                  onClick={() => setSelectedCard(card)}
                  className="bg-foreground text-background px-4 py-2 rounded-full font-bold text-xs"
                >
                  Set limit
                </button>
              </div>
            ))}
          </div>
        </div>
      </main>

      {selectedCard && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm p-4" onClick={() => setSelectedCard(null)}>
          <div className="bg-card w-full max-w-md rounded-t-3xl sm:rounded-3xl p-6 space-y-6 animate-in slide-in-from-bottom-full sm:zoom-in-95 duration-300" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-center sm:hidden">
              <div className="h-1.5 w-12 bg-muted rounded-full mb-2" />
            </div>
            
            {isSuccess ? (
              <div className="flex flex-col items-center justify-center py-8 space-y-4 text-center">
                <div className="h-20 w-20 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-500">
                  <CheckCircle2 size={40} />
                </div>
                <div className="space-y-1">
                  <h3 className="text-xl font-bold">Limit updated!</h3>
                  <p className="text-sm text-muted-foreground">Your new spending limit of £{limitValue} has been set.</p>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="text-xl font-bold">Set spending limit</h3>
                  <p className="text-sm text-muted-foreground">For {selectedCard.type} card •••• {selectedCard.last4}</p>
                </div>

                <div className="space-y-4">
                  <div className="bg-secondary rounded-2xl p-6 text-center">
                    <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-1">Monthly limit</div>
                    <div className="flex items-center justify-center gap-2">
                      <span className="text-4xl font-bold text-foreground">£</span>
                      <input 
                        type="number" 
                        value={limitValue}
                        onChange={(e) => setLimitValue(e.target.value)}
                        className="bg-transparent text-4xl font-bold text-foreground w-32 text-center outline-none"
                        autoFocus
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    {['500', '1000', '2500'].map((val) => (
                      <button 
                        key={val}
                        onClick={() => setLimitValue(val)}
                        className={cn(
                          "py-3 rounded-xl font-bold text-sm transition-colors",
                          limitValue === val ? "bg-foreground text-background" : "bg-secondary text-foreground"
                        )}
                      >
                        £{val}
                      </button>
                    ))}
                  </div>
                </div>

                <button 
                  onClick={handleSetLimit}
                  className="w-full bg-foreground text-background py-4 rounded-full font-bold text-lg shadow-lg active:scale-95 transition-transform"
                >
                  Confirm limit
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default CardSpendingLimitsPage;
