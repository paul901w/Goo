import React from 'react';
import { useNavigate } from 'react-router-dom';
import { X } from 'lucide-react';

const InboxPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between p-4 pt-6">
        <button 
          onClick={() => navigate(-1)}
          className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <X size={24} />
        </button>
        <h1 className="text-xl font-bold">Inbox</h1>
        <div className="w-10" />
      </header>
      <main className="flex-1 p-4 flex flex-col items-center justify-center text-center space-y-4">
        <div className="h-24 w-24 rounded-full bg-secondary flex items-center justify-center text-5xl">
          📩
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold">No new messages</h2>
          <p className="text-muted-foreground max-w-[280px]">We'll let you know when there's something new for you.</p>
        </div>
      </main>
    </div>
  );
};

export default InboxPage;
