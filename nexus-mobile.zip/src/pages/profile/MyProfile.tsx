import { Link, useNavigate } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { useTheme } from '@/theme/ThemeContext';
import { 
  Inbox, 
  HelpCircle, 
  FileText, 
  ShieldCheck, 
  TrendingUp, 
  Palette, 
  User, 
  ChevronRight,
  X,
  Camera,
  Users,
  Info,
  Star,
  CreditCard,
  Bell,
  Moon,
  Sun
} from 'lucide-react';
import { cn } from '@/lib/utils';

export default function MyProfile() {
  const { user } = useApp();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();

  const sections = [
    {
      title: 'Your account',
      items: [
        { icon: Bell, label: 'Inbox', path: '/profile/inbox' },
        { icon: HelpCircle, label: 'Help', path: '/profile/help' },
        { icon: FileText, label: 'Statements and reports', path: '/profile/statements' },
      ]
    },
    {
      title: 'Settings',
      items: [
        { icon: ShieldCheck, label: 'Security and privacy', sublabel: 'Change your security and privacy settings', path: '/settings/security-privacy' },
        { icon: Bell, label: 'Notifications', sublabel: 'Customise how you get updates', path: '/settings/notifications' },
        { icon: CreditCard, label: 'Payment methods', sublabel: 'Manage saved cards and bank accounts that are linked to this account', path: '/settings/payment-methods' },
        { icon: TrendingUp, label: 'Limits', sublabel: 'Manage your transfer and card limits', path: '/settings/limits' },
        { icon: Palette, label: 'Language and appearance', sublabel: 'Customise language settings and which theme is used', path: '/settings/appearance' },
        { icon: User, label: 'Personal details', sublabel: 'Update your personal information', path: '/settings/personal-details' },
      ]
    },
    {
      title: 'Actions and agreements',
      items: [
        { icon: Users, label: 'Referrals', sublabel: 'Send and manage referrals', path: '#' },
        { icon: Info, label: 'Our agreements', path: '#' },
        { icon: Star, label: 'Rate us', sublabel: 'Write a Play Store review', path: '#' },
      ]
    }
  ];

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground pb-24">
      {/* Top Bar */}
      <div className="flex items-center justify-between p-4 pt-6">
        <button 
          onClick={() => navigate(-1)}
          className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <X size={24} />
        </button>
        <div className="flex items-center gap-2">
          <button 
            onClick={toggleTheme}
            className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center"
          >
            {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          <button className="bg-foreground text-background px-4 py-2 rounded-full text-sm font-bold">
            Open an account
          </button>
        </div>
      </div>

      {/* User Header */}
      <div className="flex flex-col items-center text-center space-y-4 py-6">
        <div className="relative">
          <img 
            src={user.avatar} 
            alt={user.name} 
            className="h-20 w-20 rounded-full object-cover border-2 border-border shadow-xl"
            referrerPolicy="no-referrer"
          />
          <button className="absolute bottom-0 right-0 h-7 w-7 rounded-full bg-foreground text-background border-2 border-background flex items-center justify-center">
            <Camera size={14} />
          </button>
        </div>
        <div className="space-y-1">
          <h2 className="text-3xl font-display uppercase tracking-tight leading-none">{user.name}</h2>
          <p className="text-sm text-muted-foreground font-medium">Personal account</p>
        </div>
        <div className="bg-secondary px-3 py-1 rounded-full flex items-center gap-2 text-xs font-bold">
          <TrendingUp size={12} className="text-foreground" /> @khaledr207
        </div>
      </div>

      {/* Navigation List */}
      <div className="space-y-8 px-4 mt-8">
        {sections.map((section) => (
          <div key={section.title} className="space-y-4">
            <h3 className="text-xl font-bold px-2">
              {section.title}
            </h3>
            <div className="bg-card rounded-2xl border border-border overflow-hidden">
              {section.items.map((item, index) => (
                <Link 
                  key={item.label} 
                  to={item.path}
                  className={cn(
                    "flex items-start justify-between p-4 hover:bg-secondary/50 transition-colors",
                    index !== section.items.length - 1 && "border-b border-border"
                  )}
                >
                  <div className="flex items-start gap-4">
                    <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center shrink-0 group-active:scale-95 transition-transform">
                      <item.icon size={20} className="text-foreground" />
                    </div>
                    <div className="space-y-0.5 pt-0.5">
                      <div className="font-bold text-base leading-tight">{item.label}</div>
                      {item.sublabel && (
                        <div className="text-xs text-muted-foreground leading-snug max-w-[280px]">
                          {item.sublabel}
                        </div>
                      )}
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-muted-foreground mt-1.5" />
                </Link>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
