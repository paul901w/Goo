import React from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Search, MessageCircle, HelpCircle, FileText, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

const HelpPage: React.FC = () => {
  const navigate = useNavigate();

  const helpTopics = [
    { icon: MessageCircle, title: 'Chat with us', description: 'Get help in real-time' },
    { icon: HelpCircle, title: 'Help Center', description: 'Browse our help articles' },
    { icon: FileText, title: 'Legal', description: 'Our terms and conditions' },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between p-4 pt-6">
        <button 
          onClick={() => navigate(-1)}
          className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <X size={24} />
        </button>
        <h1 className="text-xl font-bold">Help</h1>
        <div className="w-10" />
      </header>
      <main className="flex-1 p-4 space-y-8">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search help articles"
            className="w-full pl-12 pr-4 py-4 bg-secondary rounded-2xl border-none focus:ring-2 focus:ring-foreground outline-none font-medium"
          />
        </div>

        <div className="space-y-6">
          <h2 className="text-2xl font-bold px-2">How can we help?</h2>
          <div className="bg-card rounded-2xl border border-border overflow-hidden">
            {helpTopics.map((topic, index) => (
              <button 
                key={index} 
                className={cn(
                  "w-full flex items-center justify-between p-4 hover:bg-secondary/50 transition-colors",
                  index !== helpTopics.length - 1 && "border-b border-border"
                )}
              >
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center shrink-0">
                    <topic.icon size={24} className="text-foreground" />
                  </div>
                  <div className="text-left">
                    <h3 className="font-bold text-lg leading-tight">{topic.title}</h3>
                    <p className="text-sm text-muted-foreground">{topic.description}</p>
                  </div>
                </div>
                <ChevronRight size={20} className="text-muted-foreground" />
              </button>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default HelpPage;
