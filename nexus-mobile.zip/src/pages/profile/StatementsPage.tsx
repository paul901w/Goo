import React from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Download, FileText, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

const StatementsPage: React.FC = () => {
  const navigate = useNavigate();

  const statements = [
    { month: 'March 2026', date: 'Mar 1 - Mar 26', type: 'Monthly Statement' },
    { month: 'February 2026', date: 'Feb 1 - Feb 28', type: 'Monthly Statement' },
    { month: 'January 2026', date: 'Jan 1 - Jan 31', type: 'Monthly Statement' },
    { month: 'December 2025', date: 'Dec 1 - Dec 31', type: 'Monthly Statement' },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between p-4 pt-6">
        <button 
          onClick={() => navigate(-1)}
          className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <X size={24} />
        </button>
        <h1 className="text-xl font-bold text-center flex-1">Statements and reports</h1>
        <div className="w-10" />
      </header>
      <main className="flex-1 p-4 space-y-8">
        <div className="space-y-6">
          <h2 className="text-2xl font-bold px-2">Account statements</h2>
          <div className="bg-card rounded-2xl border border-border overflow-hidden">
            {statements.map((statement, index) => (
              <button 
                key={index} 
                className={cn(
                  "w-full flex items-center justify-between p-4 hover:bg-secondary/50 transition-colors",
                  index !== statements.length - 1 && "border-b border-border"
                )}
              >
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center shrink-0">
                    <FileText size={24} className="text-foreground" />
                  </div>
                  <div className="text-left">
                    <h3 className="font-bold text-lg leading-tight">{statement.month}</h3>
                    <p className="text-sm text-muted-foreground">{statement.date}</p>
                  </div>
                </div>
                <Download size={20} className="text-foreground" />
              </button>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default StatementsPage;
