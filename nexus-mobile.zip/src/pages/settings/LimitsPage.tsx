import React from 'react';
import { useNavigate } from 'react-router-dom';
import { X, CreditCard, Send, Landmark, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

const LimitsPage: React.FC = () => {
  const navigate = useNavigate();

  const limits = [
    { icon: CreditCard, title: 'Card spending', limit: '£10,000 / month', used: '£1,240', percentage: 12.4 },
    { icon: Send, title: 'Transfers', limit: '£50,000 / day', used: '£2,500', percentage: 5 },
    { icon: Landmark, title: 'Bank withdrawals', limit: '£20,000 / day', used: '£0', percentage: 0 },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between p-4 pt-6">
        <button 
          onClick={() => navigate(-1)}
          className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <X size={24} />
        </button>
        <h1 className="text-xl font-bold">Account limits</h1>
        <div className="w-10" />
      </header>
      <main className="flex-1 p-4 space-y-8">
        <div className="space-y-6">
          <h2 className="text-2xl font-bold px-2">Spending & transfers</h2>
          <div className="bg-card rounded-2xl border border-border overflow-hidden">
            {limits.map((limit, index) => (
              <button 
                key={index} 
                className={cn(
                  "w-full flex flex-col p-4 hover:bg-secondary/50 transition-colors",
                  index !== limits.length - 1 && "border-b border-border"
                )}
              >
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center shrink-0">
                      <limit.icon size={24} className="text-foreground" />
                    </div>
                    <div className="text-left">
                      <h3 className="font-bold text-lg leading-tight">{limit.title}</h3>
                      <p className="text-sm text-muted-foreground">{limit.limit}</p>
                    </div>
                  </div>
                  <ChevronRight size={20} className="text-muted-foreground" />
                </div>
                <div className="space-y-2 w-full pt-4">
                  <div className="flex justify-between text-sm font-medium">
                    <span className="text-muted-foreground">Used: {limit.used}</span>
                    <span className="text-muted-foreground">{100 - limit.percentage}% left</span>
                  </div>
                  <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-foreground rounded-full" 
                      style={{ width: `${limit.percentage}%` }}
                    />
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default LimitsPage;
