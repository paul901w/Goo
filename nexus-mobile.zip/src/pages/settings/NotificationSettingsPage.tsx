import React from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Bell, CreditCard, Send, Shield, ChevronRight } from 'lucide-react';

const NotificationSettingsPage: React.FC = () => {
  const navigate = useNavigate();

  const notifications = [
    { icon: Send, title: 'Payments', description: 'Transfers and requests' },
    { icon: CreditCard, title: 'Card Activity', description: 'Spending and card use' },
    { icon: Shield, title: 'Security Alerts', description: 'Login and security updates' },
    { icon: Bell, title: 'Promotions', description: 'Offers and updates' },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between p-4 pt-6">
        <button 
          onClick={() => navigate(-1)}
          className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <X size={24} />
        </button>
        <h1 className="text-xl font-bold">Notifications</h1>
        <div className="w-10" />
      </header>
      <main className="flex-1 p-4 space-y-8">
        <div className="space-y-6">
          <h2 className="text-2xl font-bold px-2">Customise how you get updates</h2>
          <div className="space-y-2">
            {notifications.map((notif, index) => (
              <button key={index} className="w-full flex items-center justify-between p-4 group">
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center shrink-0">
                    <notif.icon size={24} className="text-foreground" />
                  </div>
                  <div className="text-left">
                    <h3 className="font-bold text-lg leading-tight">{notif.title}</h3>
                    <p className="text-sm text-muted-foreground">{notif.description}</p>
                  </div>
                </div>
                <div className="w-12 h-7 bg-foreground rounded-full relative cursor-pointer">
                  <div className="absolute right-1 top-1 w-5 h-5 bg-background rounded-full shadow-sm" />
                </div>
              </button>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default NotificationSettingsPage;
