import React from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Plus, CreditCard, Landmark, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

const PaymentMethodsPage: React.FC = () => {
  const navigate = useNavigate();

  const methods = [
    { icon: CreditCard, title: 'Visa Debit', description: 'Ending in 4242' },
    { icon: Landmark, title: 'Bank Account', description: 'Ending in 8899' },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between p-4 pt-6">
        <button 
          onClick={() => navigate(-1)}
          className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <X size={24} />
        </button>
        <h1 className="text-xl font-bold">Payment methods</h1>
        <div className="w-10" />
      </header>
      <main className="flex-1 p-4 space-y-8">
        <div className="space-y-6">
          <div className="flex items-center justify-between px-2">
            <h2 className="text-2xl font-bold">Saved methods</h2>
            <button className="flex items-center gap-1 text-foreground font-bold">
              <Plus size={20} /> Add
            </button>
          </div>
          <div className="bg-card rounded-2xl border border-border overflow-hidden">
            {methods.map((method, index) => (
              <button 
                key={index} 
                className={cn(
                  "w-full flex items-center justify-between p-4 hover:bg-secondary/50 transition-colors",
                  index !== methods.length - 1 && "border-b border-border"
                )}
              >
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center shrink-0">
                    <method.icon size={24} className="text-foreground" />
                  </div>
                  <div className="text-left">
                    <h3 className="font-bold text-lg leading-tight">{method.title}</h3>
                    <p className="text-sm text-muted-foreground">{method.description}</p>
                  </div>
                </div>
                <ChevronRight size={20} className="text-muted-foreground" />
              </button>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default PaymentMethodsPage;
