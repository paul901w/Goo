import React from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Shield, Lock, Eye, Smartphone, ChevronRight } from 'lucide-react';

const SecurityPrivacyPage: React.FC = () => {
  const navigate = useNavigate();

  const settings = [
    { icon: Lock, title: 'Change Passcode', description: 'Update your login PIN' },
    { icon: Smartphone, title: 'Biometric Login', description: 'Use Face ID or Fingerprint' },
    { icon: Shield, title: 'Two-Step Verification', description: 'Enhance account security' },
    { icon: Eye, title: 'Privacy Settings', description: 'Manage your visibility' },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="flex items-center p-4 border-b border-border">
        <button 
          onClick={() => navigate(-1)}
          className="p-2 hover:bg-secondary rounded-full transition-colors"
        >
          <X size={24} />
        </button>
        <h1 className="ml-4 text-xl font-bold">Security and privacy</h1>
      </header>
      
      <main className="flex-1 p-4 space-y-6">
        <div className="bg-card rounded-2xl border border-border overflow-hidden">
          {settings.map((setting, index) => (
            <button key={index} className="w-full flex items-center justify-between p-4 hover:bg-secondary/50 transition-colors border-b border-border last:border-0">
              <div className="flex items-center gap-4">
                <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center">
                  <setting.icon size={20} className="text-muted-foreground" />
                </div>
                <div className="text-left">
                  <div className="font-medium">{setting.title}</div>
                  <div className="text-xs text-muted-foreground">{setting.description}</div>
                </div>
              </div>
              <ChevronRight size={20} className="text-muted-foreground" />
            </button>
          ))}
        </div>
      </main>
    </div>
  );
};

export default SecurityPrivacyPage;
