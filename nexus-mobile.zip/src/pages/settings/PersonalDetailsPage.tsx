import React from 'react';
import { useNavigate } from 'react-router-dom';
import { X, User, Mail, Phone, MapPin, ChevronRight } from 'lucide-react';
import { useApp } from '@/context/AppContext';

const PersonalDetailsPage: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useApp();

  const details = [
    { icon: User, title: 'Full Name', value: user.name },
    { icon: Mail, title: 'Email Address', value: user.email },
    { icon: Phone, title: 'Phone Number', value: '+44 7700 900000' },
    { icon: MapPin, title: 'Residential Address', value: '123 Banking Lane, London, UK' },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="flex items-center p-4 border-b border-border">
        <button 
          onClick={() => navigate(-1)}
          className="p-2 hover:bg-secondary rounded-full transition-colors"
        >
          <X size={24} />
        </button>
        <h1 className="ml-4 text-xl font-bold">Personal Details</h1>
      </header>
      
      <main className="flex-1 p-4 space-y-6">
        <div className="bg-card rounded-2xl border border-border overflow-hidden">
          {details.map((detail, index) => (
            <button key={index} className="w-full flex items-center justify-between p-4 hover:bg-secondary/50 transition-colors border-b border-border last:border-0">
              <div className="flex items-center gap-4">
                <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center">
                  <detail.icon size={20} className="text-muted-foreground" />
                </div>
                <div className="text-left">
                  <div className="text-xs text-muted-foreground">{detail.title}</div>
                  <div className="font-medium">{detail.value}</div>
                </div>
              </div>
              <ChevronRight size={20} className="text-muted-foreground" />
            </button>
          ))}
        </div>
      </main>
    </div>
  );
};

export default PersonalDetailsPage;
