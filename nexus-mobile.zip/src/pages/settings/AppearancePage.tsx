import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Sun, Moon, Monitor, X, Check } from 'lucide-react';
import { useTheme } from '@/theme/ThemeContext';
import { cn } from '@/lib/utils';

const AppearancePage: React.FC = () => {
  const navigate = useNavigate();
  const { theme, setTheme } = useTheme();

  const themes = [
    { id: 'light', icon: Sun, title: 'Light' },
    { id: 'dark', icon: Moon, title: 'Dark' },
    { id: 'system', icon: Monitor, title: 'System default' },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <header className="flex items-center p-4 border-b border-border">
        <button 
          onClick={() => navigate(-1)}
          className="p-2 hover:bg-secondary rounded-full transition-colors"
        >
          <ChevronLeft size={24} />
        </button>
        <h1 className="ml-4 text-xl font-bold">Appearance</h1>
      </header>

      <main className="flex-1 p-4 space-y-6">
        <div className="space-y-4">
          <h2 className="text-sm font-bold text-muted-foreground uppercase tracking-wider px-2">Choose theme</h2>
          <div className="bg-card rounded-2xl border border-border overflow-hidden">
            {themes.map((t, index) => (
              <button
                key={t.id}
                onClick={() => setTheme(t.id as any)}
                className={cn(
                  "w-full flex items-center justify-between p-4 hover:bg-secondary/50 transition-colors",
                  index !== themes.length - 1 && "border-b border-border"
                )}
              >
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "h-10 w-10 rounded-full flex items-center justify-center",
                    theme === t.id ? "bg-foreground/10 text-foreground" : "bg-secondary text-muted-foreground"
                  )}>
                    <t.icon size={20} />
                  </div>
                  <span className="font-medium">{t.title}</span>
                </div>
                {theme === t.id && (
                  <div className="h-6 w-6 rounded-full bg-foreground flex items-center justify-center">
                    <Check size={14} className="text-background" />
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default AppearancePage;
