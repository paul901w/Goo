import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useEffect } from 'react';
import { ThemeProvider } from './theme/ThemeContext';
import { AppProvider } from './context/AppContext';
import { AppLayout } from './components/AppLayout';
import ScrollToTop from './components/ScrollToTop';

// Main Tab Pages
import HomeDashboard from './pages/home/HomeDashboard';
import CardsPage from './pages/cards/CardsPage';
import RecipientsPage from './pages/recipients/RecipientsPage';
import PaymentsPage from './pages/payments/PaymentsPage';
import AccountDetailsPage from './pages/payments/AccountDetailsPage';
import MyProfile from './pages/profile/MyProfile';

// Profile/General Subpages
import InboxPage from './pages/profile/InboxPage';
import HelpPage from './pages/profile/HelpPage';
import StatementsPage from './pages/profile/StatementsPage';

// Settings Subpages
import SecurityPrivacyPage from './pages/settings/SecurityPrivacyPage';
import NotificationSettingsPage from './pages/settings/NotificationSettingsPage';
import PaymentMethodsPage from './pages/settings/PaymentMethodsPage';
import LimitsPage from './pages/settings/LimitsPage';
import AppearancePage from './pages/settings/AppearancePage';
import PersonalDetailsPage from './pages/settings/PersonalDetailsPage';

import CardControlsPage from './pages/cards/CardControlsPage';
import CardSpendingLimitsPage from './pages/cards/CardSpendingLimitsPage';
import TransactionsPage from './pages/cards/TransactionsPage';
import UnblockPinPage from './pages/cards/UnblockPinPage';
import EditCardPage from './pages/cards/EditCardPage';
import ReplaceCardPage from './pages/cards/ReplaceCardPage';
import DeleteCardPage from './pages/cards/DeleteCardPage';

export default function App() {
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const button = target.closest('button');
      if (button) {
        button.classList.add('trigger-light-slide');
        setTimeout(() => {
          button.classList.remove('trigger-light-slide');
        }, 400); // Match animation duration
      }
    };
    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, []);

  return (
    <ThemeProvider>
      <AppProvider>
        <BrowserRouter>
          <ScrollToTop />
          <Routes>
            <Route element={<AppLayout />}>
              {/* Main Tabs */}
              <Route path="/" element={<HomeDashboard />} />
              <Route path="/cards" element={<CardsPage />} />
              <Route path="/cards/controls" element={<CardControlsPage />} />
              <Route path="/cards/spending-limits" element={<CardSpendingLimitsPage />} />
              <Route path="/cards/transactions" element={<TransactionsPage />} />
              <Route path="/cards/unblock-pin" element={<UnblockPinPage />} />
              <Route path="/cards/edit" element={<EditCardPage />} />
              <Route path="/cards/replace" element={<ReplaceCardPage />} />
              <Route path="/cards/delete" element={<DeleteCardPage />} />
              <Route path="/recipients" element={<RecipientsPage />} />
              <Route path="/payments" element={<PaymentsPage />} />
              <Route path="/payments/account-details/:code" element={<AccountDetailsPage />} />
              <Route path="/profile" element={<MyProfile />} />

              {/* Profile Subpages */}
              <Route path="/profile/inbox" element={<InboxPage />} />
              <Route path="/profile/help" element={<HelpPage />} />
              <Route path="/profile/statements" element={<StatementsPage />} />

              {/* Settings Subpages */}
              <Route path="/settings/security-privacy" element={<SecurityPrivacyPage />} />
              <Route path="/settings/notifications" element={<NotificationSettingsPage />} />
              <Route path="/settings/payment-methods" element={<PaymentMethodsPage />} />
              <Route path="/settings/limits" element={<LimitsPage />} />
              <Route path="/settings/appearance" element={<AppearancePage />} />
              <Route path="/settings/personal-details" element={<PersonalDetailsPage />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </AppProvider>
    </ThemeProvider>
  );
}

