import React from 'react';
import { cn } from '@/lib/utils';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  padding?: boolean;
  className?: string;
  children?: React.ReactNode;
  onClick?: React.MouseEventHandler<HTMLDivElement>;
  key?: React.Key;
}

export const Card = ({ className, padding = true, ...props }: CardProps) => {
  return (
    <div
      className={cn(
        'rounded-3xl border border-border bg-card text-card-foreground shadow-sm overflow-hidden',
        padding && 'p-4',
        className
      )}
      {...props}
    />
  );
};
