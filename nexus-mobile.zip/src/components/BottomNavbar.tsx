import { NavLink } from 'react-router-dom';
import { Home, CreditCard, Users, ArrowUpRight } from 'lucide-react';
import { cn } from '@/lib/utils';

export const BottomNavbar = () => {
  const navItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: CreditCard, label: 'Cards', path: '/cards' },
    { icon: Users, label: 'Recipients', path: '/recipients' },
    { icon: ArrowUpRight, label: 'Payments', path: '/payments' },
  ];

  return (
    <nav className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 w-[calc(100%-32px)] max-w-[368px] bg-background/40 backdrop-blur-md border border-border/25 rounded-[32px] shadow-[0_8px_32px_rgba(0,0,0,0.12)] overflow-hidden">
      <div className="flex justify-around items-center h-16 px-2">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              cn(
                'flex flex-col items-center justify-center gap-1 w-full h-full transition-all duration-300',
                isActive ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'
              )
            }
          >
            {({ isActive }) => (
              <>
                <div className={cn(
                  "p-1.5 rounded-xl transition-colors",
                  isActive ? "bg-foreground/10" : "bg-transparent"
                )}>
                  <item.icon size={20} strokeWidth={isActive ? 2 : 1.5} />
                </div>
                <span className={cn(
                  "text-[9px] font-semibold uppercase tracking-[0.1em] transition-opacity",
                  isActive ? "opacity-100" : "opacity-60"
                )}>{item.label}</span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  );
};
