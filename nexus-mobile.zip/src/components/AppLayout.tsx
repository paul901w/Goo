import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { BottomNavbar } from './BottomNavbar';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft } from 'lucide-react';
import { Button } from './Button';
import { useApp } from '@/context/AppContext';
import { useTheme } from '@/theme/ThemeContext';
import { cn } from '@/lib/utils';

export const AppLayout = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { theme } = useTheme();

  const mainTabs = ['/', '/cards', '/recipients', '/payments'];
  const isRootPath = mainTabs.includes(location.pathname);

  return (
    <div className={cn("mobile-container noise-bg", theme === 'dark' ? 'dark' : '')}>
      {/* Main Content */}
      <main className="flex-1 pb-20 overflow-x-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="w-full"
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Navigation */}
      <BottomNavbar />
    </div>
  );
};
