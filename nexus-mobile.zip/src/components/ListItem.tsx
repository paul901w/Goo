import React from 'react';
import { cn } from '@/lib/utils';

interface ListItemProps extends React.HTMLAttributes<HTMLDivElement> {
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  title: string;
  subtitle?: string;
  className?: string;
  children?: React.ReactNode;
  key?: React.Key;
}

export const ListItem = ({ leftIcon, rightIcon, title, subtitle, className, ...props }: ListItemProps) => {
  return (
    <div
      className={cn(
        'flex items-center justify-between p-4 hover:bg-accent/50 transition-colors cursor-pointer border-b last:border-0',
        className
      )}
      {...props}
    >
      <div className="flex items-center gap-3">
        {leftIcon && <div className="text-muted-foreground">{leftIcon}</div>}
        <div>
          <div className="font-medium">{title}</div>
          {subtitle && <div className="text-xs text-muted-foreground">{subtitle}</div>}
        </div>
      </div>
      {rightIcon && <div className="text-muted-foreground">{rightIcon}</div>}
    </div>
  );
};
