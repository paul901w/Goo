export const MOCK_USER = {
  id: 'u1',
  name: 'KHALED RAHENE',
  email: 'khaledr207@gmail.com',
  avatar: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?q=80&w=2043&auto=format&fit=crop',
  totalBalance: 12450.75,
  currency: 'GBP',
};

export const MOCK_ACCOUNTS = [
  { id: 'acc1', currency: 'GBP', balance: 8450.25, symbol: '£', name: 'British Pound' },
  { id: 'acc2', currency: 'EUR', balance: 3200.50, symbol: '€', name: 'Euro' },
  { id: 'acc3', currency: 'USD', balance: 800.00, symbol: '$', name: 'US Dollar' },
];

export const MOCK_TRANSACTIONS = [
  { id: 't1', title: 'Starbucks Coffee', category: 'Food & Drink', amount: -4.50, currency: 'GBP', date: 'Today, 10:45 AM', status: 'Completed', icon: 'Coffee' },
  { id: 't2', title: 'Salary Deposit', category: 'Income', amount: 3200.00, currency: 'GBP', date: 'Yesterday', status: 'Completed', icon: 'ArrowDownLeft' },
  { id: 't3', title: 'Apple Store', category: 'Shopping', amount: -129.00, currency: 'GBP', date: '2 days ago', status: 'Completed', icon: 'ShoppingBag' },
  { id: 't4', title: 'Rent Payment', category: 'Housing', amount: -1200.00, currency: 'GBP', date: 'Mar 1, 2026', status: 'Completed', icon: 'Home' },
  { id: 't5', title: 'Netflix Subscription', category: 'Entertainment', amount: -12.99, currency: 'GBP', date: 'Feb 28, 2026', status: 'Completed', icon: 'Tv' },
];

export const MOCK_CARDS = [
  { id: 'c1', type: 'Physical', last4: '4242', brand: 'Visa', status: 'Active', color: 'bg-brand' },
  { id: 'c2', type: 'Virtual', last4: '8892', brand: 'Mastercard', status: 'Active', color: 'bg-slate-800' },
  { id: 'c3', type: 'Virtual', last4: '1123', brand: 'Visa', status: 'Frozen', color: 'bg-slate-500' },
];

export const MOCK_RECIPIENTS = [
  { id: 'r1', name: 'Sarah Chen', username: 'schen_dev', avatar: 'https://picsum.photos/seed/sarah/200', bank: 'Barclays' },
  { id: 'r2', name: 'Jordan Smith', username: 'jsmith', avatar: 'https://picsum.photos/seed/jordan/200', bank: 'HSBC' },
  { id: 'r3', name: 'Emma Wilson', username: 'ewilson', avatar: 'https://picsum.photos/seed/emma/200', bank: 'Monzo' },
  { id: 'r4', name: 'David Miller', username: 'dmiller', avatar: 'https://picsum.photos/seed/david/200', bank: 'Revolut' },
];
