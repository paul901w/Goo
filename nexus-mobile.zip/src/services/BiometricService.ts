/**
 * Biometric authentication service using WebAuthn API.
 * This provides a way to request user verification (fingerprint, face, etc.)
 * using the platform's native authenticator.
 */

export async function isBiometricAvailable(): Promise<boolean> {
  if (!window.PublicKeyCredential) return false;
  
  try {
    const available = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    return available;
  } catch (e) {
    return false;
  }
}

export async function authenticateWithBiometrics(): Promise<boolean> {
  if (!window.PublicKeyCredential) return false;

  try {
    const isAvailable = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    if (!isAvailable) return false;

    const challenge = new Uint8Array(32);
    window.crypto.getRandomValues(challenge);

    // To trigger the native biometric prompt, we can use a "dummy" create request.
    // This will show the OS-level fingerprint/FaceID/PIN dialog.
    // Note: This won't "verify" against a server, but it forces the user to scan.
    const credential = await navigator.credentials.create({
      publicKey: {
        challenge,
        rp: { name: "Wise Applet", id: window.location.hostname },
        user: {
          id: new Uint8Array(16),
          name: "user@example.com",
          displayName: "User"
        },
        pubKeyCredParams: [{ alg: -7, type: "public-key" }],
        authenticatorSelection: {
          authenticatorAttachment: "platform",
          userVerification: "required"
        },
        timeout: 60000
      }
    });

    return !!credential;
  } catch (e) {
    // We don't log the error here to avoid cluttering the console 
    // when running in restricted environments like iframes.
    return false;
  }
}
