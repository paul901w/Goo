import React, { createContext, useContext, useState, useEffect } from 'react';
import { MOCK_USER, MOCK_ACCOUNTS, MOCK_TRANSACTIONS, MOCK_CARDS, MOCK_RECIPIENTS } from '@/data/mockData';

export interface Transaction {
  id: string;
  title: string;
  category: string;
  amount: number;
  currency: string;
  date: string;
  status: string;
  icon: string;
}

export interface Account {
  id: string;
  currency: string;
  balance: number;
  symbol: string;
  name: string;
}

export interface Card {
  id: string;
  type: string;
  last4: string;
  brand: string;
  status: string;
  color: string;
}

export interface Recipient {
  id: string;
  name: string;
  username: string;
  avatar: string;
  bank: string;
}

interface AppContextType {
  user: typeof MOCK_USER;
  accounts: Account[];
  transactions: Transaction[];
  cards: Card[];
  recipients: Recipient[];
  isBalanceVisible: boolean;
  setIsBalanceVisible: (visible: boolean) => void;
  addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  toggleCardStatus: (cardId: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState(MOCK_USER);
  const [accounts, setAccounts] = useState<Account[]>(MOCK_ACCOUNTS);
  const [transactions, setTransactions] = useState<Transaction[]>(MOCK_TRANSACTIONS);
  const [cards, setCards] = useState<Card[]>(MOCK_CARDS);
  const [recipients, setRecipients] = useState<Recipient[]>(MOCK_RECIPIENTS);
  const [isBalanceVisible, setIsBalanceVisible] = useState(true);

  const addTransaction = (transaction: Omit<Transaction, 'id'>) => {
    const newTransaction = { ...transaction, id: `t${Date.now()}` };
    setTransactions(prev => [newTransaction, ...prev]);
    
    // Update balance logic (simplified)
    if (transaction.currency === user.currency) {
      setUser(prev => ({ ...prev, totalBalance: prev.totalBalance + transaction.amount }));
    }
    setAccounts(prev => prev.map(acc => {
      if (acc.currency === transaction.currency) {
        return { ...acc, balance: acc.balance + transaction.amount };
      }
      return acc;
    }));
  };

  const toggleCardStatus = (cardId: string) => {
    setCards(prev => prev.map(card => {
      if (card.id === cardId) {
        return { ...card, status: card.status === 'Active' ? 'Frozen' : 'Active' };
      }
      return card;
    }));
  };

  return (
    <AppContext.Provider value={{ 
      user,
      accounts,
      transactions,
      cards,
      recipients,
      isBalanceVisible,
      setIsBalanceVisible,
      addTransaction,
      toggleCardStatus
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
